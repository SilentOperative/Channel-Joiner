// inject.js — PWX Ads Skipper DOM patcher

(function () {
  function patch() {
    // ── 1. Replace ALL hardcoded links from the original extension ─────────
    document.querySelectorAll("a").forEach((a) => {
      const href = a.href || "";

      // SQ Tech website → PWX
      if (href.includes("sqtech.dev")) {
        a.href = "http://pwx.onrender.com/";
      }

      // Old Telegram link → PWX Telegram
      if (href.includes("t.me/sharoon1998")) {
        a.href = "https://web.telegram.org/k/#@pwxonrender";
      }

      // Hide GitHub issues link (and its button wrapper)
      if (href.includes("github.com")) {
        let el = a;
        for (let i = 0; i < 5; i++) {
          if (el.parentElement && el.parentElement.children.length <= 3 &&
              el.parentElement !== document.body) {
            el = el.parentElement;
          } else break;
        }
        el.style.display = "none";
      }

      // Hide Email link
      if (a.textContent.trim().toLowerCase() === "email") {
        let el = a;
        for (let i = 0; i < 5; i++) {
          if (el.parentElement && el.parentElement.children.length <= 3 &&
              el.parentElement !== document.body) {
            el = el.parentElement;
          } else break;
        }
        el.style.display = "none";
      }
    });

    // ── 2. Hide "View supported sites" button + its section ───────────────
    document.querySelectorAll("button, a").forEach((el) => {
      if (el.textContent.trim() === "View supported sites") {
        let parent = el;
        for (let i = 0; i < 8; i++) {
          if (!parent.parentElement || parent.parentElement === document.body) break;
          parent = parent.parentElement;
          if (parent.offsetHeight > 20 && parent.offsetHeight < 300) {
            parent.style.display = "none";
            break;
          }
        }
      }
    });

    // ── 3. Hide Chrome Web Store rating section ────────────────────────────
    document.querySelectorAll("button, a").forEach((el) => {
      if (el.textContent.includes("Rate on Chrome")) {
        let parent = el;
        for (let i = 0; i < 8; i++) {
          if (!parent.parentElement || parent.parentElement === document.body) break;
          parent = parent.parentElement;
          if (parent.offsetHeight > 20 && parent.offsetHeight < 250) {
            parent.style.display = "none";
            break;
          }
        }
      }
    });

    // ── 3. Replace "SQ Tech" text with "Gourav Saini" ─────────────────────
    document.querySelectorAll("*").forEach((node) => {
      if (node.children.length === 0 && node.textContent.includes("SQ Tech")) {
        node.textContent = node.textContent.replace("SQ Tech", "Gourav Saini");
      }
    });

    // ── 4. Replace "Skip Wait" header title ───────────────────────────────
    document.querySelectorAll("*").forEach((node) => {
      if (node.children.length === 0 && node.textContent.trim() === "Skip Wait") {
        node.textContent = "PWX Ads Skipper";
      }
    });

    // ── 5. Inject branded footer bar ──────────────────────────────────────
    if (!document.getElementById("pwx-footer")) {
      const bar = document.createElement("div");
      bar.id = "pwx-footer";
      bar.innerHTML = `
        <a href="http://pwx.onrender.com/" target="_blank" rel="noopener">Powered by PWX</a>
        <span class="pwx-sep">·</span>
        <a href="https://web.telegram.org/k/#@pwxonrender" target="_blank" rel="noopener">Telegram</a>
        <span class="pwx-sep">·</span>
        <span class="pwx-credit">Made by Gourav Saini</span>
      `;
      document.body.appendChild(bar);
    }
  }

  const observer = new MutationObserver(() => {
    const root = document.getElementById("root");
    if (root && root.children.length > 0) {
      observer.disconnect();
      setTimeout(patch, 80);
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      observer.observe(document.body, { childList: true, subtree: true });
    });
  } else {
    observer.observe(document.body, { childList: true, subtree: true });
  }
})();
